<?php
system('shutdown -r -t 0');
?>